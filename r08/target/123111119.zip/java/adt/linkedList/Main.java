package adt.linkedList;

public class Main {
  public static void main(String[] args) {
    // RecursiveDoubleLinkedListImpl<Integer> debl = new
    // RecursiveDoubleLinkedListImpl<>();

    // debl.insertFirst(4);
    // debl.insertFirst(2);
    // debl.removeLast();
    // debl.removeLast();
    // debl.insertFirst(6);

    // SingleLinkedListImpl<Integer> debl = new SingleLinkedListImpl<>();

    // debl.insert(4);
    // debl.insert(2);
    // debl.insert(6);
    // debl.remove(2);
  }
}
