package inicio;

public interface A<T>{
  public void m(T o);
}
