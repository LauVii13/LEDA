package inicio;

public interface B extends A<String> {
}
