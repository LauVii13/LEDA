package inicio;

public class C<T> implements A<T>{
  
  public void m(T o){
    return;
  }
}
