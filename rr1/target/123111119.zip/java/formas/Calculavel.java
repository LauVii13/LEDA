package formas;

public interface Calculavel {
    public double calculaArea();
}
